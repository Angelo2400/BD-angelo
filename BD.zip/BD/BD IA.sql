CREATE TABLE `Desarrollador` (
  `ID` int(11) NOT NULL,
  `Herramientas` varchar(255) NOT NULL,
  `Calificaciones` varchar(255) NOT NULL,
  `Nivel experiencia` varchar(255) NOT NULL,
  `Cantidad de proyectos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



CREATE TABLE `Empresa` (
  `ID` int(11) NOT NULL,
  `Ingreso anual` int(11) NOT NULL,
  `Valor del mercado` int(11) NOT NULL,
  `Numero de patente` int(11) NOT NULL,
  `ID_desarrollador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


CREATE TABLE `IA` (
  `Tasa de precios` int(11) NOT NULL,
  `Lenguaje de programacion` varchar(255) NOT NULL,
  `Requerimientos de hardware` varchar(255) NOT NULL,
  `EmpresaID` int(10) UNSIGNED NOT NULL,
  `ID` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


ALTER TABLE `Desarrollador`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `Empresa`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Empresa_ID_desarrollador_Desarrollador` (`ID_desarrollador`);

ALTER TABLE `IA`
  ADD PRIMARY KEY (`ID`);

ALTER TABLE `Desarrollador`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Empresa`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `IA`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `Empresa`
  ADD CONSTRAINT `Empresa_ID_desarrollador_Desarrollador` FOREIGN KEY (`ID_desarrollador`) REFERENCES `Empresa` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;